# Hardhat tests

These tests run using hardhat and can be run locally by

### Installing

```bash
npm install -g pnpm
pnpm install
npx hardhat compile
```

### Testing

```bash
npx hardhat test
```

### Clean

```bash
rm -rf node_modules
npx hardhat clean
```
